jQuery(document).ready(function() {
	jQuery('input[placeholder], textarea[placeholder]').placeholder();
});